package ParkingSystem;

import java.util.List;
import java.util.Optional;

public abstract class ParkingSpotManager {
    private List<ParkingSpot> parkingSpotList;
    private ParkingAssignStrategy parkingAssignStrategy;

    public ParkingSpotManager(List<ParkingSpot> parkingSpotList) {
        this.parkingSpotList = parkingSpotList;
    }

    public ParkingSpotManager(List<ParkingSpot> parkingSpotList, ParkingAssignStrategy parkingAssignStrategy) {
        this.parkingSpotList = parkingSpotList;
        this.parkingAssignStrategy = parkingAssignStrategy;
    }

    public List<ParkingSpot> getParkingSpotList() {
        return parkingSpotList;
    }

    public void setParkingSpotList(List<ParkingSpot> parkingSpotList) {
        this.parkingSpotList = parkingSpotList;
    }

    public ParkingAssignStrategy getParkingAssignStrategy() {
        return parkingAssignStrategy;
    }

    public void setParkingAssignStrategy(ParkingAssignStrategy parkingAssignStrategy) {
        this.parkingAssignStrategy = parkingAssignStrategy;
    }

    public Optional<ParkingSpot> findAvailableParkingSpot(Vehicle vehicle, String entryGateId){
        return parkingAssignStrategy.findParkingSpot(parkingSpotList,vehicle,entryGateId);
    }

    public abstract void addParkingSpot(int id);

    public void removeParkingSpot(int parkingSpotId){
        Optional<ParkingSpot> parkingSpot = parkingSpotList.stream().filter(ps -> ps.getId() == parkingSpotId).findFirst();
        if(parkingSpot.isPresent()){
            parkingSpotList.remove(parkingSpot.get());
        }else
            System.out.println("Could not find parking spot with this id.");
    }

    public void parkVehicle(ParkingSpot spot , Vehicle vehicle){
        spot.parkVehicle(vehicle);
    }

    public void removeVehicle(ParkingSpot spot , Vehicle vehicle){
        parkingAssignStrategy.vacateParkingSpot(spot,vehicle);
        spot.removeVehicle(vehicle);
    }
}
