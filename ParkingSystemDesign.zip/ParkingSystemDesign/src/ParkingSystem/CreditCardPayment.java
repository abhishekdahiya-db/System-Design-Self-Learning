package ParkingSystem;

public class CreditCardPayment implements Payment{
    @Override
    public void pay(Double amount) {
        System.out.println("Credit card payment for amount "+amount+" is completed.");
    }
}
