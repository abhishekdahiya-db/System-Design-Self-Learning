package ParkingSystem;

import java.util.List;
import java.util.Optional;

public interface ParkingAssignStrategy {
    public Optional<ParkingSpot> findParkingSpot(List<ParkingSpot> parkingSpotList , Vehicle vehicle, String entryGateId);
    public void vacateParkingSpot(ParkingSpot spot, Vehicle vehicle);
}
