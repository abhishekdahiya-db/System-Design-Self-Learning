package ParkingSystem;

public abstract class ParkingSpot {
    private int id;
    private Status parkingSpotStatus;

    private Vehicle vehicle;
    public ParkingSpot(int id, Status parkingSpotStatus) {
        this.id = id;
        this.parkingSpotStatus = parkingSpotStatus;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Status getParkingSpotStatus() {
        return parkingSpotStatus;
    }

    public void setParkingSpotStatus(Status parkingSpotStatus) {
        this.parkingSpotStatus = parkingSpotStatus;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public void parkVehicle(Vehicle vehicle){
        if(parkingSpotStatus.equals(Status.IDLE)){
            parkingSpotStatus = Status.OCCUPIED;
            this.vehicle=vehicle;
            System.out.println("Parked vehicle "+vehicle.getRegistrationNumber()+" at parking spot "+id);
        }else
            System.out.println("Parking Spot "+id+" is already occupied");
    }

    public void removeVehicle(Vehicle vehicle){
        if(parkingSpotStatus.equals(Status.OCCUPIED)){
            parkingSpotStatus = Status.IDLE;
            this.vehicle=null;
            System.out.println("Parked vehicle "+vehicle.getRegistrationNumber()+" is removed from parking spot "+id);
        }else
            System.out.println("No vehicle parked at parking Spot "+id);
    }
}
