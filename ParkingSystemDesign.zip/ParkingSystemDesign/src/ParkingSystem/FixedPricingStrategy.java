package ParkingSystem;

public class FixedPricingStrategy implements PricingStrategy{
    @Override
    public Double price(Ticket ticket) {
        VehicleType vehicleType = ticket.getVehicle().getType();
        if(vehicleType.equals(VehicleType.TWO_WHEELER)) return Constants.TWO_WHEELER_PRICE;
        else if(vehicleType.equals(VehicleType.FOUR_WHEELER)) return Constants.FOUR_WHEELER_PRICE;
        return (double) 0;
    }
}
