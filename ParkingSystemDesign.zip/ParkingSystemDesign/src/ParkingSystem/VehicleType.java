package ParkingSystem;

public enum VehicleType {
    TWO_WHEELER,FOUR_WHEELER;
}
