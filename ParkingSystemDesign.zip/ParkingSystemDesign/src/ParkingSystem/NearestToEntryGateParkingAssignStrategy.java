package ParkingSystem;

import java.util.List;
import java.util.Optional;

public class NearestToEntryGateParkingAssignStrategy implements ParkingAssignStrategy{
    @Override
    public Optional<ParkingSpot> findParkingSpot(List<ParkingSpot> parkingSpotList, Vehicle vehicle, String entryGateId) {
        // we will keep a min heap of parking spot for each entry gate to return the nearest.
        // once a parking spot is returned from any gate's we need to remove it from all min heaps of all gates
        // distance of any entry gate and parking spot will be denotes of coordinates , dis = (x1-x2)+(y1-y2)
        return Optional.empty();
    }

    @Override
    public void vacateParkingSpot(ParkingSpot spot, Vehicle vehicle) {
        // if we have to vacate a parking spot then we will add it back to min heap of all entry gates.
    }
}
