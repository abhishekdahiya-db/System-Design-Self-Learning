package ParkingSystem;

import java.time.LocalDateTime;
import java.util.Optional;

public class EntryGate {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EntryGate(String id) {
        this.id = id;
    }

    public Optional<Ticket> generateTicket(Vehicle vehicle){
        ParkingSpotManager parkingSpotManager = ParkingSpotManagerFactory.getParkingSpotManager(vehicle.getType());
        Optional<ParkingSpot> parkingSpotOpt = parkingSpotManager.findAvailableParkingSpot(vehicle,id);
        if(parkingSpotOpt.isPresent()){
            ParkingSpot spot = parkingSpotOpt.get();
            System.out.println("found parking spot "+spot.getId() +"for vehicle" + vehicle.getRegistrationNumber());
            Ticket ticket = new Ticket(LocalDateTime.now(),vehicle,spot);
            parkingSpotManager.parkVehicle(spot,vehicle);
            return Optional.of(ticket);
        }else{
            System.out.println("no idle parking spot available for vehicle type "+vehicle.getType());
            return Optional.empty();
        }
    }
}
