package ParkingSystem;

import java.util.List;
import java.util.Optional;

public class RandomParkingAssignStrategy implements ParkingAssignStrategy{
    @Override
    public Optional<ParkingSpot> findParkingSpot(List<ParkingSpot> parkingSpotList, Vehicle vehicle, String entryGateId) {
        return parkingSpotList.stream().filter(ps -> ps.getParkingSpotStatus().equals(Status.IDLE)).findAny();
    }

    @Override
    public void vacateParkingSpot(ParkingSpot spot, Vehicle vehicle) {

    }
}
