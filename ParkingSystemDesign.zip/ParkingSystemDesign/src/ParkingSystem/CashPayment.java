package ParkingSystem;

public class CashPayment implements Payment{
    private PaymentType paymentType;

    @Override
    public void pay(Double amount) {
        System.out.println("Cash payment for amount "+amount+" is completed.");
    }
}
