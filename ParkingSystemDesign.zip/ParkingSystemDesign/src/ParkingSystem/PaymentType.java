package ParkingSystem;

public enum PaymentType {
    CASH_PAYMENT,CREDIT_CARD_PAYMENT;
}
