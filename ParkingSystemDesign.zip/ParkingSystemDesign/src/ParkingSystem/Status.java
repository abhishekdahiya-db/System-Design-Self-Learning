package ParkingSystem;

public enum Status {
    IDLE,OCCUPIED;
}
