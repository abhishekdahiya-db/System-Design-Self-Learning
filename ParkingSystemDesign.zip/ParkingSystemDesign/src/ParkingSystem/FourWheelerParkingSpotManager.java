package ParkingSystem;

import java.util.ArrayList;
import java.util.List;

public class FourWheelerParkingSpotManager extends ParkingSpotManager{
    public FourWheelerParkingSpotManager() {
        super(new ArrayList<>());
    }

    public FourWheelerParkingSpotManager(ParkingAssignStrategy parkingAssignStrategy) {
        super(new ArrayList<>(), parkingAssignStrategy);
    }

    @Override
    public void addParkingSpot(int id) {
        getParkingSpotList().add(new FourWheelerParkingSpot(id,Status.IDLE,Constants.FOUR_WHEELER_PRICE));
    }
}
