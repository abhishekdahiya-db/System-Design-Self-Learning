package ParkingSystem;

public class CostComputaion {
    private PricingStrategy pricingStrategy;

    public CostComputaion(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    public CostComputaion() {

    }

    public PricingStrategy getPricingStrategy() {
        return pricingStrategy;
    }

    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    public double calculatePrice(Ticket ticket){
        return pricingStrategy.price(ticket);
    }
}
