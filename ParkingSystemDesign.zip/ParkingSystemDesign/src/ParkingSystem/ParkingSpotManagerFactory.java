package ParkingSystem;

import com.sun.source.tree.ReturnTree;

import java.util.ArrayList;

public class ParkingSpotManagerFactory {
    private static ParkingSpotManager twoWheelerParkingSpotManager = new TwoWheelerParkingSpotManager();
    private static ParkingSpotManager fourWheelerParkingSpotManager = new FourWheelerParkingSpotManager();
    public static ParkingSpotManager getParkingSpotManager(VehicleType type){
        if(type.equals(VehicleType.FOUR_WHEELER)){
            return fourWheelerParkingSpotManager;
        }else if(type.equals(VehicleType.TWO_WHEELER)){
            return twoWheelerParkingSpotManager;
        }
        return null;
    }
}
