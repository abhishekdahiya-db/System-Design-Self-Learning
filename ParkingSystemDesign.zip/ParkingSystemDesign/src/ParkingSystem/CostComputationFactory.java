package ParkingSystem;

public class CostComputationFactory {
    private static TwoWheelerCostComputation twoWheelerCostComputation = new TwoWheelerCostComputation();
    private static FourWheelerCostComputation fourWheelerCostComputation = new FourWheelerCostComputation();
    public static CostComputaion getCostComputationObject(VehicleType type){
        if(type.equals(VehicleType.TWO_WHEELER)){
            return twoWheelerCostComputation;
        }else if(type.equals(VehicleType.FOUR_WHEELER)){
            return fourWheelerCostComputation;
        }
        return null;
    }
}
