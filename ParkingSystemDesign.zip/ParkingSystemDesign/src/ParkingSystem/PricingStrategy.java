package ParkingSystem;

public interface PricingStrategy {
    public Double price(Ticket ticket);
}
