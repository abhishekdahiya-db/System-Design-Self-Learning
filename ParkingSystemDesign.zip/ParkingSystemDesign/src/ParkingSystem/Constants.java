package ParkingSystem;

public class Constants {
    public static final double TWO_WHEELER_PRICE = 20;
    public static final double FOUR_WHEELER_PRICE = 40;
}
