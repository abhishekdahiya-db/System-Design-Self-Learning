package ParkingSystem;

public class PaymentFactory {
    public static Payment getPaymentObject(PaymentType type){
        if(type.equals(PaymentType.CASH_PAYMENT)) {
            return new CashPayment();
        }
        else if(type.equals(PaymentType.CREDIT_CARD_PAYMENT)) {
            return new CreditCardPayment();
        }
        return null;
    }
}
