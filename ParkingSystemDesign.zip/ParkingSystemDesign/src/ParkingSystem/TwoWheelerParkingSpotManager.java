package ParkingSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TwoWheelerParkingSpotManager extends ParkingSpotManager{
    public TwoWheelerParkingSpotManager() {
        super(new ArrayList<>());
    }

    public TwoWheelerParkingSpotManager(ParkingAssignStrategy parkingAssignStrategy) {
        super(new ArrayList<>(), parkingAssignStrategy);
    }

    @Override
    public void addParkingSpot(int id) {
        getParkingSpotList().add(new TwoWheelerParkingSpot(id,Status.IDLE,Constants.TWO_WHEELER_PRICE));
    }
}
