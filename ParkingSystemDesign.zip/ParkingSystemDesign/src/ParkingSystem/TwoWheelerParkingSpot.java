package ParkingSystem;

public class TwoWheelerParkingSpot extends ParkingSpot{
    private double price;
    public TwoWheelerParkingSpot(int id, Status parkingSpotStatus,double price) {
        super(id, parkingSpotStatus);
        this.price=price;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
