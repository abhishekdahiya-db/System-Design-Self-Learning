package ParkingSystem;

public interface Payment {
    public void pay(Double amount);
}
