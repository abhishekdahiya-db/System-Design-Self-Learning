package ParkingSystem;

public class FourWheelerCostComputation extends CostComputaion{
    public FourWheelerCostComputation(PricingStrategy pricingStrategy) {
        super(pricingStrategy);
    }

    public FourWheelerCostComputation() {
    }
}
