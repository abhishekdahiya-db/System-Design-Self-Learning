package ParkingSystem;

public class ExitGate {
    private String id;

    public ExitGate(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Double priceCalculation(Ticket ticket){
        double cost = CostComputationFactory.getCostComputationObject(ticket.getVehicle().getType()).calculatePrice(ticket);
        System.out.print("cost for parking vehicle "+ ticket.getVehicle().getRegistrationNumber()+" is "+cost);
        return cost;
    }

    public void makePayment(Double amount,PaymentType type,Ticket ticket){
        VehicleType vehicleType = ticket.getVehicle().getType();
        PaymentFactory.getPaymentObject(type).pay(amount);
        ParkingSpotManagerFactory.getParkingSpotManager(vehicleType).removeVehicle(ticket.getParkingSpot(), ticket.getVehicle());
    }

}
