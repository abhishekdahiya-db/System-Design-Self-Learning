package ParkingSystem;

public class TwoWheelerCostComputation extends CostComputaion{
    public TwoWheelerCostComputation(PricingStrategy pricingStrategy) {
        super(pricingStrategy);
    }

    public TwoWheelerCostComputation() {
    }
}
