package ParkingSystem;

import java.time.LocalDateTime;

public class HourlyPricingStrategy implements PricingStrategy{
    @Override
    public Double price(Ticket ticket) {
        int hours = LocalDateTime.now().getHour() - ticket.getEntryTime().getHour()+1;
        double hourlyRate = 0;
        VehicleType vehicleType = ticket.getVehicle().getType();
        if(vehicleType.equals(VehicleType.TWO_WHEELER)) hourlyRate = Constants.FOUR_WHEELER_PRICE;
        else if(vehicleType.equals(VehicleType.TWO_WHEELER)) hourlyRate = Constants.TWO_WHEELER_PRICE;
        return hours*hourlyRate;
    }
}
