import ParkingSystem.*;

import java.util.Optional;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        // creating a parking system of 100 capacity -> 60 4 wheeler 40 2 wheeler
        // testing with 1,1 capacity for 2 and 4 wheeler to test non empty space cases.
        ParkingSpotManager twoWheelerParkingSpotManager = ParkingSpotManagerFactory.getParkingSpotManager(VehicleType.TWO_WHEELER);
        for(int i=1; i<=1 ; ++i){
            twoWheelerParkingSpotManager.addParkingSpot(i);
        }
        ParkingSpotManager fourWheelerParkingSpotManager = ParkingSpotManagerFactory.getParkingSpotManager(VehicleType.FOUR_WHEELER);
        for(int i=1 ; i<=1 ; ++i){
            fourWheelerParkingSpotManager.addParkingSpot(i);
        }
        twoWheelerParkingSpotManager.setParkingAssignStrategy(new RandomParkingAssignStrategy());
        fourWheelerParkingSpotManager.setParkingAssignStrategy(new RandomParkingAssignStrategy());

        EntryGate entryGate1 = new EntryGate(UUID.randomUUID().toString());
        EntryGate entryGate2 = new EntryGate(UUID.randomUUID().toString());

        ExitGate exitGate1 = new ExitGate(UUID.randomUUID().toString());
        ExitGate exitGate2 = new ExitGate(UUID.randomUUID().toString());

        CostComputaion twoWheelerCostComputation = CostComputationFactory.getCostComputationObject(VehicleType.TWO_WHEELER);
        twoWheelerCostComputation.setPricingStrategy(new FixedPricingStrategy());
        CostComputaion fourWheelerCostComputation = (FourWheelerCostComputation) CostComputationFactory.getCostComputationObject(VehicleType.FOUR_WHEELER);
        fourWheelerCostComputation.setPricingStrategy(new FixedPricingStrategy());

        Vehicle baleno = new Vehicle("HR10XY4112",VehicleType.FOUR_WHEELER);
        Vehicle altroz = new Vehicle("Dubeys8008",VehicleType.FOUR_WHEELER);
        Vehicle meteor = new Vehicle("HR10AB2853",VehicleType.TWO_WHEELER);

        Optional<Ticket> ticketOptional1 = entryGate1.generateTicket(baleno);
        Optional<Ticket> ticketOptional2 = entryGate2.generateTicket(altroz);
        Optional<Ticket> ticketOptional3 = entryGate1.generateTicket(meteor);

        if(ticketOptional1.isPresent()){
            double amount = exitGate2.priceCalculation(ticketOptional1.get());
            exitGate2.makePayment(amount,PaymentType.CASH_PAYMENT,ticketOptional1.get());
        }
        ticketOptional2 = entryGate2.generateTicket(altroz);
        if(ticketOptional3.isPresent()){
            double amount = exitGate1.priceCalculation(ticketOptional3.get());
            exitGate2.makePayment(amount,PaymentType.CREDIT_CARD_PAYMENT,ticketOptional3.get());
        }
    }
}