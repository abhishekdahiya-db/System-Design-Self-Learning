package expense;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.User;

import java.util.List;
import java.util.PriorityQueue;


@Data
@AllArgsConstructor
public class Expense {
    private String expenseId;
    private String expenseName;
    private Double amount;
    private User paidBy;
    private SplitType splitType;
    private List<Split> splits;
}
