package expense;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class UnequalExpenseValidator implements ExpenseSplitValidator{
    @Override
    public boolean validateExpenseRequest(Expense e) {
        return e.getSplits().stream().mapToDouble(Split::getShareAmount).sum() == e.getAmount();
    }
}
