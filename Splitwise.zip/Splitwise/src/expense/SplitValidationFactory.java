package expense;

public class SplitValidationFactory {
    public static ExpenseSplitValidator getValidatorInstance(SplitType type){
        if(type.equals(SplitType.EQUAL)) return new EqualExpenseValidator();
        else if(type.equals(SplitType.UNEQUAL)) return new UnequalExpenseValidator();
        else if(type.equals(SplitType.PERCENTAGE)) return new PercentageExpenseValidator();
        else return null;
    }
}
