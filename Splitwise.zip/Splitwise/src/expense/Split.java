package expense;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.User;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Split {
    private User user;
    private Double shareAmount;
}
