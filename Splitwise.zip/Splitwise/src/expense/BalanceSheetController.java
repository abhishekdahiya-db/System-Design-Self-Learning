package expense;

import lombok.NoArgsConstructor;
import user.Balance;
import user.User;

import java.util.Map;

@NoArgsConstructor
public class BalanceSheetController {
    public void updateBalanceSheetForExpense(Expense expense){
        double totalAmount = expense.getAmount();
        User paidBy = expense.getPaidBy();
        for(Split split : expense.getSplits()){
            User expenseUser = split.getUser();
            if(!expenseUser.equals(paidBy)){
                double owedAmount = split.getShareAmount();
                double totalExpense = split.getUser().getBalanceSheet().getTotalExpense();
                double totalOwed = split.getUser().getBalanceSheet().getOwe();
                expenseUser.getBalanceSheet().setTotalExpense(totalExpense+owedAmount);
                expenseUser.getBalanceSheet().setOwe(totalOwed+owedAmount);
                Map<String,Balance> expenseUsersFriendMap = expenseUser.getBalanceSheet().getFriendBalanceMap();
                //expenseUsersFriendMap.putIfAbsent(paidBy,new Balance());
                Balance paidByBalance = expenseUsersFriendMap.getOrDefault(paidBy.getUserName(),new Balance());
                double friendOwed = paidByBalance.getOwe();
                paidByBalance.setOwe(friendOwed+owedAmount);
                expenseUsersFriendMap.put(paidBy.getUserName(),paidByBalance);
                Map<String,Balance> paidUsersFriendMap = paidBy.getBalanceSheet().getFriendBalanceMap();
                //paidUsersFriendMap.putIfAbsent(expenseUser,new Balance());
                Balance paidByFriendBalance = paidUsersFriendMap.getOrDefault(expenseUser.getUserName(),new Balance());
                double paidUserGetBack = paidByFriendBalance.getGetBack();
                paidByFriendBalance.setGetBack(paidUserGetBack+owedAmount);
                paidUsersFriendMap.put(expenseUser.getUserName(),paidByFriendBalance);
            }else{
                double expenseAmount = split.getShareAmount();
                double totalExpense = paidBy.getBalanceSheet().getTotalExpense();
                double totalPayment = paidBy.getBalanceSheet().getTotalPayment();
                paidBy.getBalanceSheet().setTotalPayment(totalPayment+totalAmount);
                paidBy.getBalanceSheet().setTotalExpense(totalExpense+expenseAmount);
                double totalGetBack = split.getUser().getBalanceSheet().getGetBack();
                paidBy.getBalanceSheet().setGetBack(totalGetBack + (totalAmount-expenseAmount));
            }
        }
    }
}
