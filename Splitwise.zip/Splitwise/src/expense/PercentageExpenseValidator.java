package expense;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class PercentageExpenseValidator implements ExpenseSplitValidator{
    @Override
    public boolean validateExpenseRequest(Expense e) {
        return false;
    }
}
