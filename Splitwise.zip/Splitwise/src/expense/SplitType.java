package expense;

public enum SplitType {
    EQUAL,UNEQUAL,PERCENTAGE;
}
