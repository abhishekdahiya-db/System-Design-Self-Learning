package expense;

public interface ExpenseSplitValidator {
    public boolean validateExpenseRequest(Expense e);
}
