package expense;

import lombok.AllArgsConstructor;
import user.User;

import java.util.List;
import java.util.UUID;

@AllArgsConstructor
public class ExpenseController {
    private BalanceSheetController balanceSheetController;

    public ExpenseController() {
        this.balanceSheetController = new BalanceSheetController();
    }

    public Expense createExpense(List<Split> splits, double amount, User paidByUser,SplitType type, String expenseName){
        Expense newExpense = new Expense(UUID.randomUUID().toString(),expenseName,amount,paidByUser,type,splits);
        ExpenseSplitValidator validatorInstance = SplitValidationFactory.getValidatorInstance(type);
        if(validatorInstance.validateExpenseRequest(newExpense)){
            balanceSheetController.updateBalanceSheetForExpense(newExpense);
            return newExpense;
        }else{
            System.out.println("expense splits are wrong , please try again later");
            return null;
        }
    }
}
