package expense;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class EqualExpenseValidator implements ExpenseSplitValidator{
    @Override
    public boolean validateExpenseRequest(Expense e) {
        double individualAmount = e.getAmount()/(e.getSplits().size());
        return e.getSplits().stream().allMatch(s -> s.getShareAmount().equals(individualAmount));
    }
}
