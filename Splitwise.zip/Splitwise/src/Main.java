import expense.Split;
import expense.SplitType;
import splitwise.Splitwise;
import user.User;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Splitwise app = new Splitwise();
        app.init();
        // add users to splitwise
        app.addUser("1","Suhani");
        app.addUser("2","Abhishek");
        app.addUser("3","Mohit");
        app.addUser("4","Upendra");

        // add groups in splitwise
        app.addGroup("1","Ghar kharch");
        app.addGroup("2","Outing");

        //add user to groups
        app.addUserToGroup("Mohit","3","Ghar Kharch");
        app.addUserToGroup("Abhishek","2","Ghar Kharch");
        app.addUserToGroup("Suhani","1","Outing");
        app.addUserToGroup("Upendra","4","Outing");
        app.addUserToGroup("Abhishek","2","Outing");

        System.out.println("Displaying Balance Sheet of Abhishek");
        app.displayBalanceSheet("2","Abhishek");
        System.out.println("----------------------------------------");

        // splitlist comes from ui
        User abhishek = app.getUserController().getSplitwiseUsers().stream().filter(u -> u.getUserid().equals("2")).findAny().get();
        User suhani = app.getUserController().getSplitwiseUsers().stream().filter(u -> u.getUserid().equals("1")).findAny().get();
        User upendra = app.getUserController().getSplitwiseUsers().stream().filter(u -> u.getUserid().equals("4")).findAny().get();
        List<Split> splitList = new ArrayList<>();
        splitList.add(new Split(abhishek,500.0));
        splitList.add(new Split(suhani,500.0));
        //negitive case
        //app.addExpense(splitList,1100.0,suhani, SplitType.EQUAL,"Trampoline Park");

        app.addExpense(splitList,1000.0,suhani, SplitType.EQUAL,"Trampoline Park");
        System.out.println("Displaying Balance Sheet of Abhishek");
        app.displayBalanceSheet("2","Abhishek");
        System.out.println("----------------------------------------");
        System.out.println("Displaying Balance Sheet of Suhani");
        app.displayBalanceSheet("1","Suhani");
        System.out.println("----------------------------------------");

        splitList.clear();
        splitList.add(new Split(abhishek,700.0));
        splitList.add(new Split(suhani,500.0));
        splitList.add(new Split(upendra,400.0));

        app.addGroupExpense(splitList,1600.0,abhishek,SplitType.UNEQUAL,"movie","Outing");
        System.out.println("Displaying Balance Sheet of Abhishek");
        app.displayBalanceSheet("2","Abhishek");
        System.out.println("----------------------------------------");
        System.out.println("Displaying Balance Sheet of Suhani");
        app.displayBalanceSheet("1","Suhani");
        System.out.println("----------------------------------------");
        System.out.println("Displaying Balance Sheet of Upendra");
        app.displayBalanceSheet("4","Upendra");
        System.out.println("----------------------------------------");
    }
}