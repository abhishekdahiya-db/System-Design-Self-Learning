package group;

import expense.Expense;
import expense.ExpenseController;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.User;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@Data
public class Group {
    private String groupId;
    private String groupName;
    private List<User> members;
    private List<Expense> expenseList;
    private ExpenseController expenseController;

    public Group() {
        this.members = new ArrayList<>();
        this.expenseList = new ArrayList<>();
    }
}
