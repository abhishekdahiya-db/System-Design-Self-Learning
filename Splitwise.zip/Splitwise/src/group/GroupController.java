package group;

import expense.Expense;
import expense.ExpenseController;
import expense.Split;
import expense.SplitType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.User;
import user.UserController;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Data
public class GroupController {
    private List<Group> splitwiseGroups;
    public void addGroup(String groupId, String groupName, ExpenseController expenseController){
        Group newGroup = new Group();
        newGroup.setGroupId(groupId);
        newGroup.setGroupName(groupName);
        newGroup.setExpenseController(expenseController);
        System.out.println("created group "+newGroup.getGroupName()+" in splitwise app.");
        splitwiseGroups.add(newGroup);
    }

    public void addUser(User user,String groupName){
        splitwiseGroups.stream().filter(g -> g.getGroupName().equals(groupName)).forEach(g -> g.getMembers().add(user));
    }

    public void removeUser(User user,String groupName){
        splitwiseGroups.stream().filter(g -> g.getGroupName().equals(groupName)).forEach(g -> g.getMembers().remove(user));
    }

    public void addExpense(List<Split> splits, double amount, User paidByUser, SplitType type, String expenseName,String groupName){
        Optional<Group> groupOpt = splitwiseGroups.stream().filter(g -> g.getGroupName().equals(groupName)).findAny();
        if(groupOpt.isPresent()){
            Expense newExpense = groupOpt.get().getExpenseController().createExpense(splits,amount,paidByUser,type,expenseName);
            if(newExpense!=null) groupOpt.get().getExpenseList().add(newExpense);
        }else{
            System.out.println("No such group exists.");
        }
    }
}
