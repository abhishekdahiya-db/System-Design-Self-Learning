package user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Data
public class UserController {
    private List<User> splitwiseUsers;

    public void addUser(String userid,String userName){
        User newUser = new User(userid,userName,new UserBalanceSheet());
        splitwiseUsers.add(newUser);
        System.out.println("new user "+userName+" has been added to splitwise");
    }

    public void editUserName(String userid, String newName){
        Optional<User> userOpt = splitwiseUsers.stream().filter(u -> u.getUserid().equals(userid)).findAny();
        if(userOpt.isPresent()){
            System.out.println("User name has been changed from "+userOpt.get().getUserName() + " to "+newName);
            userOpt.get().setUserName(newName);
        }else System.out.println("No user present with given id");
    }
}
