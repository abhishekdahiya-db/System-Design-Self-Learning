package user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@ToString
public class Balance {
    private double owe;
    private double getBack;

    public Balance() {
        this.owe=0;
        this.getBack=0;
    }
}
