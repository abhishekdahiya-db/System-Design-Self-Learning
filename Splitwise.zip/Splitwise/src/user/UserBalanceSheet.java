package user;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class UserBalanceSheet {
    private Map<String,Balance> friendBalanceMap;
    private double owe;
    private double getBack;
    private double totalPayment;
    private double totalExpense;

    public UserBalanceSheet() {
        this.friendBalanceMap = new HashMap<>();
        this.owe=0;
        this.getBack=0;
        this.totalPayment=0;
        this.totalExpense=0;
    }

    public void display(){
        System.out.println("Total owed : " + owe);
        System.out.println("Total get back : " + getBack);
        System.out.println("Total Payment done : "+totalPayment);
        System.out.println("Total Expense : "+totalExpense);
        System.out.println("Friend Balance");
        for(Map.Entry<String,Balance> entry : friendBalanceMap.entrySet()){
            System.out.println(entry.getKey() + " " + entry.getValue().toString());
        }
    }

}
