package splitwise;

import expense.*;
import group.GroupController;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import user.User;
import user.UserController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Data
@NoArgsConstructor
public class Splitwise {
    private UserController userController;
    private GroupController groupController;
    private ExpenseController expenseController;

    public void init(){
        this.userController = new UserController(new ArrayList<>());
        this.expenseController = new ExpenseController();
        this.groupController = new GroupController(new ArrayList<>());
    }

    public void addUser(String userId, String userName){
        userController.addUser(userId,userName);
    }

    public void editUser(String userId, String userName){
        userController.editUserName(userId,userName);
    }

    public void addGroup(String groupId, String groupName){
        groupController.addGroup(groupId,groupName,expenseController);
    }

    public void addUserToGroup(String userName, String userId ,String groupName){
        Optional<User> userOpt = userController.getSplitwiseUsers().stream().filter(u -> u.getUserid().equals(userId)).findAny();
        if(userOpt.isPresent()){
            System.out.println("Found user "+userName+" and adding in group "+groupName);
            groupController.addUser(userOpt.get(),groupName);
        }else{
            System.out.println("user "+userName+" is not a part of splitwise app.");
        }
    }

    public void removeUsedFromGroup(String userName, String userId, String groupName){
        Optional<User> userOpt = userController.getSplitwiseUsers().stream().filter(u -> u.getUserid().equals(userId)).findAny();
        if(userOpt.isPresent()){
            System.out.println("Found user "+userName+" and removing from group "+groupName);
            groupController.removeUser(userOpt.get(),groupName);
        }else{
            System.out.println("user "+userName+" is not a part of splitwise app.");
        }
    }

    public void addExpense(List<Split> splits, double amount, User paidByUser, SplitType type, String expenseName){
        expenseController.createExpense(splits,amount,paidByUser,type,expenseName);
    }

    public void addGroupExpense(List<Split> splits, double amount, User paidByUser, SplitType type, String expenseName,String groupName){
        groupController.addExpense(splits,amount,paidByUser,type,expenseName,groupName);
    }

    public void displayBalanceSheet(String userId,String userName){
        Optional<User> userOpt = userController.getSplitwiseUsers().stream().filter(u -> u.getUserid().equals(userId)).findAny();
        if(userOpt.isPresent()){
            userOpt.get().getBalanceSheet().display();
        }else{
            System.out.println("No such user found.");
        }
    }

}
