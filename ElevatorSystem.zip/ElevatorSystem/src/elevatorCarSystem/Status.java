package elevatorCarSystem;

public enum Status {
    MOVING,IDLE;
}
