package elevatorCarSystem;

import java.util.List;

public class MinSeekTimeDispatchingStrategy implements ExternalButtonDispatchingStrategy{

    @Override
    public ElevatorController dispatchController(List<ElevatorController> controllers, Direction direction, int floor, int floorNumber) {
        ElevatorController dispatchedController = null;
        int minDistance=Integer.MAX_VALUE;
        for(ElevatorController controller : controllers){
            int dist = getDistance(controller,direction,floor,floorNumber);
            if(minDistance > dist){
                minDistance = dist;
                dispatchedController = controller;
            }
        }
        return dispatchedController;
    }

    private int getDistance(ElevatorController controller , Direction direction , int floor , int n){
        int liftFloor = controller.getElevatorCar().getCurrentFloor();
        Direction elevatorDirection = controller.getElevatorCar().getDirection();
        Status elevatorStatus = controller.getElevatorCar().getStatus();
        if(elevatorStatus.equals(Status.IDLE))
            return Math.abs(floor-liftFloor);
        else if(!elevatorDirection.equals(direction)) return 2*n-(floor+liftFloor);
        else{
            if((elevatorDirection.equals(Direction.UP) && liftFloor<=floor) ||
                    (elevatorDirection.equals(Direction.DOWN) && liftFloor>=floor)) return Math.abs(floor-liftFloor);
            else return 2*n + Math.abs(floor-liftFloor);
        }
    }
}
