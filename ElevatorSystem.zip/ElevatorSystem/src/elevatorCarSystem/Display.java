package elevatorCarSystem;

public class Display {
    private int floor;
    private Direction direction;

    private Status status;

    public Display(int floor, Direction direction, Status status) {
        this.floor = floor;
        this.direction = direction;
        this.status = status;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void display(){
        System.out.println("current floor : "+floor);
        if(status.equals(Status.IDLE)){
            System.out.println("elevatorCar is stationary.");
        }
        else System.out.println("elevator can is moving in : "+direction+" direction");
    }
}
