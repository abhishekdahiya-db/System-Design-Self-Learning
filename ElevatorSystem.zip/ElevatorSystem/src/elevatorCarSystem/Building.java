package elevatorCarSystem;

import java.util.List;

public class Building {
     private List<Floor> floorList;

    public Building(List<Floor> floorList) {
        this.floorList = floorList;
    }
}
