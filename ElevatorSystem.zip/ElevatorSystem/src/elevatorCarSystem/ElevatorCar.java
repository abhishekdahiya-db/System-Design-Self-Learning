package elevatorCarSystem;

public class ElevatorCar {
    private int liftId;
    private int currentFloor;
    private Direction direction;
    private Status status;
    private InternalButton button;
    private Door door;

    private Display display;

    public ElevatorCar(int liftId, int currentFloor, Direction direction, Status status, InternalButton button, Door door, Display display) {
        this.liftId = liftId;
        this.currentFloor = currentFloor;
        this.direction = direction;
        this.status = status;
        this.button = button;
        this.door = door;
        this.display = display;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public InternalButton getButton() {
        return button;
    }

    public void setButton(InternalButton button) {
        this.button = button;
    }

    public Door getDoor() {
        return door;
    }

    public void setDoor(Door door) {
        this.door = door;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public int getLiftId() {
        return liftId;
    }

    public void setLiftId(int liftId) {
        this.liftId = liftId;
    }

    public void move(int destination , Direction dir){
        System.out.println("elevator Car is moving from "+currentFloor+" to "+destination+" in "+dir+" direction");
        display.setDirection(dir);
        display.setStatus(Status.MOVING);
        display.setFloor(destination);
        display.display();
        setCurrentFloor(destination);
    }
}
