package elevatorCarSystem;

public class InternalButton {
    private InternalButtonDispatcher dispatcher;

    public InternalButton(InternalButtonDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public InternalButtonDispatcher getDispatcher() {
        return dispatcher;
    }

    public void setDispatcher(InternalButtonDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    public void pressButton(int floorId, int  liftId){
        dispatcher.submitRequest(floorId,liftId);
    }
}
