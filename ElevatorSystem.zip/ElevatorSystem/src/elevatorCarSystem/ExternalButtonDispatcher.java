package elevatorCarSystem;

import java.util.List;

public class ExternalButtonDispatcher {
    private ExternalButtonDispatchingStrategy dispatchingStrategy;
    private List<ElevatorController> controllers;

    public ExternalButtonDispatcher(ExternalButtonDispatchingStrategy dispatchingStrategy, List<ElevatorController> controllers) {
        this.dispatchingStrategy = dispatchingStrategy;
        this.controllers = controllers;
    }

    public void submitRequest(int floor, Direction direction,int floorNumbers){
        ElevatorController controller = dispatchingStrategy.dispatchController(controllers,direction,floor,floorNumbers);
        controller.acceptRequest(floor,direction);
    }
}
