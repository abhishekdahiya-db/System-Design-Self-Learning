package elevatorCarSystem;

public enum Direction {
    UP,DOWN;
}
