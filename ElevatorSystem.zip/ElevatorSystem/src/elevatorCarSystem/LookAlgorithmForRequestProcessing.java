package elevatorCarSystem;

import java.util.LinkedList;
import java.util.Optional;
import java.util.PriorityQueue;
import java.util.Queue;

public class LookAlgorithmForRequestProcessing implements ElevatorCarRequestProcessingStrategy{
    private ElevatorCar elevatorCar;
    private PriorityQueue<Integer> upQueue;
    private PriorityQueue<Integer> downQueue;
    private Queue<Integer> pendingQueue;
    public LookAlgorithmForRequestProcessing(ElevatorCar elevatorCar) {
        this.elevatorCar = elevatorCar;
        upQueue = new PriorityQueue<>((p1,p2)->p1-p2);
        downQueue = new PriorityQueue<>((p1,p2)->p2-p1);
        pendingQueue = new LinkedList<>();
    }

    @Override
    public void accept(int destinationFloor, Direction direction) {
        System.out.println("accepting request for floor "+destinationFloor+" to direction "+direction+" for elevator "+elevatorCar.getLiftId());
        if(elevatorCar.getStatus().equals(Status.IDLE) || elevatorCar.getDirection().equals(Direction.UP)){
            if(direction.equals(Direction.UP)){
                if(elevatorCar.getCurrentFloor() <= destinationFloor) upQueue.add(destinationFloor);
                else pendingQueue.add(destinationFloor);
            }else downQueue.add(destinationFloor);
        }else{
            if(direction.equals(Direction.DOWN)){
                if(elevatorCar.getCurrentFloor() >= destinationFloor) downQueue.add(destinationFloor);
                else pendingQueue.add(destinationFloor);
            }else upQueue.add(destinationFloor);
        }
    }

    @Override
    public Optional<Integer> fulfillRequest() {
        if(elevatorCar.getStatus().equals(Status.IDLE)){
            if(!upQueue.isEmpty()) {
                int destination = upQueue.poll();
                return Optional.of(destination);
            }else if(!downQueue.isEmpty()) {
                int destination = downQueue.poll();
                return Optional.of(destination);
            }else return Optional.empty();
        }else{
            if(elevatorCar.getDirection().equals(Direction.UP)){
                if(!upQueue.isEmpty()) return Optional.of(upQueue.poll());
                else{
                    if(!downQueue.isEmpty() && downQueue.peek() >= elevatorCar.getCurrentFloor())
                        return Optional.of(downQueue.poll());
                    else if(!downQueue.isEmpty()){
                        while(!pendingQueue.isEmpty()){
                            upQueue.add(pendingQueue.poll());
                        }
                        return Optional.of(downQueue.poll());
                    }else return Optional.empty();
                }
            }else{
                if(!downQueue.isEmpty()) return Optional.of(downQueue.poll());
                else{
                    if(!upQueue.isEmpty() && upQueue.peek() <= elevatorCar.getCurrentFloor())
                        return Optional.of(upQueue.poll());
                    else if(!upQueue.isEmpty()){
                        while(!pendingQueue.isEmpty()){
                            downQueue.add(pendingQueue.poll());
                        }
                        return Optional.of(upQueue.poll());
                    }else return Optional.empty();
                }
            }
        }
    }
}
