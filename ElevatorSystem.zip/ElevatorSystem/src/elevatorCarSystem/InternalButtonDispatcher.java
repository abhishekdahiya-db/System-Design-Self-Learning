package elevatorCarSystem;

import java.util.List;
import java.util.Optional;

public class InternalButtonDispatcher {
    private List<ElevatorController> controllers;

    public InternalButtonDispatcher(List<ElevatorController> controllers) {
        this.controllers = controllers;
    }

    public List<ElevatorController> getControllers() {
        return controllers;
    }

    public void setControllers(List<ElevatorController> controllers) {
        this.controllers = controllers;
    }

    public void submitRequest(int floorId, int liftId){
        Optional<ElevatorController> controllerOpt = controllers.stream().filter(c -> c.getElevatorCar().getLiftId() == liftId).findAny();
        if(controllerOpt.isPresent()){
            Direction dir = controllerOpt.get().getElevatorCar().getDirection();
            controllerOpt.get().acceptRequest(floorId,dir);
        }
    }
}
