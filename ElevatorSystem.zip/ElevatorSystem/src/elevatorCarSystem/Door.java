package elevatorCarSystem;

public class Door {
    public Door() {
    }
}
