package elevatorCarSystem;

import java.util.Optional;

public interface ElevatorCarRequestProcessingStrategy {
    public void accept(int destinationFloor, Direction direction);
    public Optional<Integer> fulfillRequest();
}
