package elevatorCarSystem;

import java.util.Optional;

public class ElevatorController {
    private ElevatorCar elevatorCar;
    private ElevatorCarRequestProcessingStrategy requestProcessingStrategy;
    public ElevatorController(ElevatorCar elevatorCar, ElevatorCarRequestProcessingStrategy requestProcessingStrategy) {
        this.elevatorCar = elevatorCar;
        this.requestProcessingStrategy = requestProcessingStrategy;
    }

    public ElevatorCar getElevatorCar() {
        return elevatorCar;
    }

    public void setElevatorCar(ElevatorCar elevatorCar) {
        this.elevatorCar = elevatorCar;
    }

    public ElevatorCarRequestProcessingStrategy getRequestProcessingStrategy() {
        return requestProcessingStrategy;
    }

    public void setRequestProcessingStrategy(ElevatorCarRequestProcessingStrategy requestProcessingStrategy) {
        this.requestProcessingStrategy = requestProcessingStrategy;
    }

    public void acceptRequest(int destinationFloor, Direction direction){
        requestProcessingStrategy.accept(destinationFloor,direction);
    }
    public void controlElevatorCar() throws InterruptedException {
        while(true){
            Thread.sleep(3000);
            Optional<Integer> destinationOpt = requestProcessingStrategy.fulfillRequest();
            if(destinationOpt.isPresent()){
                elevatorCar.setDirection(elevatorCar.getCurrentFloor() < destinationOpt.get() ? Direction.UP : Direction.DOWN);
                elevatorCar.move(destinationOpt.get(),elevatorCar.getDirection());
            }else{
                elevatorCar.setStatus(Status.IDLE);
            }
        }
    }
}
