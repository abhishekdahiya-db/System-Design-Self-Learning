package elevatorCarSystem;

import java.util.List;

public interface ExternalButtonDispatchingStrategy {
    public ElevatorController dispatchController(List<ElevatorController> controllers, Direction direction , int floor, int floorNumber);
}
