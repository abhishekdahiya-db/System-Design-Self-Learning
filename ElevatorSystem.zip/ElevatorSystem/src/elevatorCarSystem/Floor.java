package elevatorCarSystem;

public class Floor {
    private int floorId;
    private ExternalButton button;

    public int getFloorId() {
        return floorId;
    }

    public void setFloorId(int floorId) {
        this.floorId = floorId;
    }

    public ExternalButton getButton() {
        return button;
    }

    public void setButton(ExternalButton button) {
        this.button = button;
    }

    public Floor(int floorId, ExternalButton button) {
        this.floorId = floorId;
        this.button = button;
    }
}
