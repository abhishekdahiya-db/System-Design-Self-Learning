package elevatorCarSystem;

public class ExternalButton {
    private ExternalButtonDispatcher dispatcher;
    private int floorId;

    private int floorNumber;
    public ExternalButton(ExternalButtonDispatcher dispatcher,int floorId, int floorNumber) {
        this.dispatcher = dispatcher;
        this.floorId = floorId;
        this.floorNumber = floorNumber;
    }

    public void pressButton(Direction direction){
        dispatcher.submitRequest(floorId,direction,floorNumber);
    }
}
