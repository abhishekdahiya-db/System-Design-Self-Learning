import elevatorCarSystem.*;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Floor> floors = new ArrayList<>();
        List<ElevatorController> controllers = new ArrayList<>();
        for(int i=1 ; i<=3 ; ++i){
            InternalButton button = new InternalButton(new InternalButtonDispatcher(null));
            Display display = new Display(0,null,Status.IDLE);
            ElevatorCar car = new ElevatorCar(i,0,null,Status.IDLE,button,new Door(),display);
            controllers.add(new ElevatorController(car,new LookAlgorithmForRequestProcessing(car)));
        }
        for(int i=0 ; i<3 ; ++i){
            controllers.stream().forEach(c -> c.getElevatorCar().getButton().getDispatcher().setControllers(controllers));
        }

        for(int i=1 ; i<=15 ; ++i){
            ExternalButton button = new ExternalButton(new ExternalButtonDispatcher(new MinSeekTimeDispatchingStrategy(),controllers),i,15);
            floors.add(new Floor(i,button));
        }
        Building building = new Building(floors);

    }
}